# Paquete de comparación JSON/CSV

**Todos los datos de este paquete son sintéticos y ficticios. No son partidas de Riot, ni datos de una cuenta real.** Los valores ilustran formatos y patrones para una demostración; no describen resultados reales de un jugador.

## Archivos

- `10-partidas.json` y `10-partidas.csv`: las mismas 10 filas, campos, orden y valores. En CSV, `NA` equivale a JSON `null` para un valor desconocido.
- `prompt-comun.txt`: pega exactamente el mismo prompt en las cuatro ejecuciones.
- `plantilla-resultados.csv`: registra local JSON, local CSV, cloud JSON y cloud CSV.
- `referencia-resultados.md`: comprobación aritmética para la persona que evalúa. **No la incluyas en el contexto ni se la entregues al modelo.**

## Comparación

Para reducir diferencias de lectura, pega el contenido de JSON o CSV como texto plano después del mismo prompt; evita rutas de carga distintas que puedan parsear los archivos de manera diferente. Conserva iguales el prompt, instrucciones adicionales, formato exigido para la respuesta y configuración/contexto del modelo cuando sea posible. Registra el nombre y versión reales, configuración, tokens y tiempo medidos en la plantilla; no asumas ni rellenes valores que la plataforma no reporte. Anota por separado errores numéricos y la calidad de las prioridades o ejercicios. La referencia ayuda a comprobar números, pero no establece una respuesta única sobre qué debe practicar el jugador ni es una respuesta modelo.

## Esquema y límites

| Campo | Tipo / unidad |
| --- | --- |
| `id` | texto, M01–M10 |
| `campeon`, `rol` | texto; todas las filas son `TOP` |
| `minutos` | entero, minutos de partida |
| `victoria` | entero, 0 o 1 |
| `kills`, `deaths`, `assists` | enteros |
| `cs_min` | número, súbditos por minuto |
| `vision_min` | número, puntuación de visión por minuto |
| `kp_pct` | entero, porcentaje de 0 a 100 |
| `muertes_antes_10` | entero o desconocido (`null` / `NA`) |
| `cola` | entero, ID 420 constante en la muestra |

Se omiten fechas y parche para evitar presentar metadatos ficticios como hechos. Las referencias TOP de 6 CS/min, 0.60 visión/min, 35% de participación y 1 muerte temprana son referencias internas de práctica, no benchmarks oficiales de rango. El paquete no contiene llamadas a Riot ni resultados de ejecución de modelos.
